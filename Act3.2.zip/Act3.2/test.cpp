//Ian De La Garza González a01283525

#include "priority_queue.h"

int main(int argc, char const *argv[])
{
    priority_queue queue;
    cout<<"array size: "<<queue.size()<<endl;
    string empty =queue.empty()?("is empty"):("not empty");
    cout<<empty<<endl;
    queue.push(28);
    //queue.print();
    queue.push(21);
    //queue.print();
    queue.push(17);
    //queue.print();
    queue.push(19);
    //queue.print();
    queue.push(5);
    queue.push(22);
    //queue.print();
    queue.push(8);
    queue.print();
    queue.pop();
    queue.print();
    queue.pop();
    queue.print();
    empty =queue.empty()?("is empty"):("not empty");
    cout<<empty<<endl;
    cout<<"array size: "<<queue.size()<<endl;
    cout<<"Top: "<<queue.top()<<endl;

    return 0;
}
