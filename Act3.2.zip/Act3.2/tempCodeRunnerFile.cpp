#include "priority_queue.h"

int main(int argc, char const *argv[])
{
    priority_queue queue;
    queue.push(28);
    queue.print();

    queue.push(19);
    queue.print();
    queue.push(21);
    queue.print();
    queue.push(5);
    queue.print();
    queue.push(17);
    queue.print();
    queue.push(8);
    queue.print();


    return 0;
}
